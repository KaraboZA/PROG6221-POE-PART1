﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestApp;

namespace TestApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //POE (PART ONE)

            External obj = new External(); //EXTERNAL CLASS OBJECT REFERENCE

            int NumberOfIngredients = 0, NumberOfsteps = 0; ;
            int[] IngredientQuantities = new int[NumberOfIngredients];
            int WhileLoopNumber = 0;
            string recipeName = "", IngredientUnitofMeasure = null;
            string[] IngredientNames = new string[NumberOfIngredients];
            string[] RecipeSteps = new string[NumberOfsteps];
            

            while (WhileLoopNumber != 1) {

                //THE FOLLOWING ARE THE MENU OPTIONS THAT WILL BE AVAILABLE TO THE USER
                Console.WriteLine("Welcome to your cookbook \n" +
                                  "\n" +
                                  "(1) Add new recipe \n" +
                                  "(2) Scale the recipe quantities \n" +
                                  "(3) Reset the quantities to original values \n" +
                                  "(4) Clear all existing data \n" +
                                  "(5) Exit");

                int MenuSelection = Convert.ToInt32(Console.ReadLine()); //THE MENU SELECTION CHOSEN BY THE USER

                if (MenuSelection == 1)
                {
                    obj.RecipeInformation(IngredientQuantities, NumberOfIngredients, IngredientNames, recipeName);
                }
                else if (MenuSelection == 2)
                {
                    obj.RecipeScale(IngredientQuantities, NumberOfIngredients); ;
                }
                else if (MenuSelection == 3)
                {
                    obj.ValueReset(IngredientQuantities);
                }
                else if (MenuSelection == 4)
                {
                    obj.DeleteValues(IngredientQuantities, RecipeSteps, IngredientNames, IngredientUnitofMeasure, recipeName); 
                }
                else if (MenuSelection == 5)
                {
                    Environment.Exit(0); //THIS STATEMENT WILL TERMINATE THE PROGRAM UPON EXECUTION
                }
                else
                {
                    Console.WriteLine("Invalid input! Please select from the available options.");
                }
            }
        }
    }
    public class External
    {

        //VARIABLE DECLARATIONS
        string recipeName, IngredientUnitofMeasure, UserInput;
        int NumberOfIngredients = 0;

        public string DeleteValues(int[] IngredientQuantities, string[] RecipeSteps, string[] IngredientNames, string IngredientUnitofMeasure, string recipeName)
        {
            Console.WriteLine("Are you sure you wish to delete all existing data [Y] or [N]: ");
            String Input = Console.ReadLine().ToUpper();

            if (Input.Equals("Y")) {
                recipeName = string.Empty;
                IngredientUnitofMeasure = string.Empty;
                Array.Clear(IngredientQuantities, 0, IngredientQuantities.Length);
                Array.Clear(RecipeSteps, 0, RecipeSteps.Length);
                Array.Clear(IngredientNames, 0, IngredientNames.Length);
                Console.WriteLine("All data has been been deleted");

            } else if (Input.Equals("N")) { 
                
            }
            return "";
        }

        public static void RecipeDisplay(string[] IngredientNames, string[] RecipeSteps, int[] IngredientQuantities, string IngredientUnitofMeasure, string recipeName) {

            Console.WriteLine("Recipe name: " + recipeName + "\n" +
                              "List of ingredients: \n");
                              foreach (string i in IngredientNames) {
                              Console.WriteLine(i);
                              }
        }

        public string RecipeInformation(int[] IngredientQuantities, int NumberOfIngredients, string[] IngredientNames, string NumberOfsteps) {

            Console.WriteLine("Enter a name for your recipe:"); //THE NAME FOR THE RECIPE
            recipeName = Console.ReadLine();

            Console.WriteLine("How many ingredients does the " + recipeName + " consist of? "); //THIS STATEMENT WILL ALLOW THE USER TO PROVIDE THE NUMBER OF INGREDIENTS
            NumberOfIngredients = Convert.ToInt32(Console.ReadLine());

            string[] RecipeSteps = new string[NumberOfIngredients]; //AN ARRAY THAT WILL STORE THE RECIPE STEPS
            IngredientQuantities = new int[NumberOfIngredients];

            //THE FOLLOWING IS A FOR-LOOP THAT WILL ALLOW THE USER TO ENTER THE INGREDIENTS IN SEQUENCE
            for (int i = 0; i < NumberOfIngredients; i++)
            {
                int sum = 1 + i;
                Console.WriteLine("Enter ingredient #" + sum);
                IngredientNames[i] = Console.ReadLine();
                Console.WriteLine("State the quantity: ");
                IngredientQuantities[i] = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Provide the unit of measure for " + IngredientNames[i] + ": ");
                IngredientUnitofMeasure = Console.ReadLine();
            }

            Console.WriteLine("Enter the number of steps associated with this recipe: ");
            NumberOfsteps = Console.ReadLine();

            //THIS SECOND FOR-LOOP WILL ALLOW THE USER TO PROVIDE THE RECIPE STEPS IN SEQUENCE
            for (int y = 0; y < int.Parse(NumberOfsteps); y++)
            {
                int step = 1 + y;
                Console.WriteLine("Enter step #" + step + " of your recipe: ");
                RecipeSteps[y] = Console.ReadLine();
            }

            return "";
        }
        public int RecipeScale(int[] IngredientQuantities, int NumberOfIngredients) {

            double Factor;
            int[] NewIngredientQuantites = new int[NumberOfIngredients];

            Console.WriteLine("Which scale do you wish to scale your recipe? (CHOOSE EITHER 0.5, 2 OR 3");
            Factor = double.Parse(Console.ReadLine());
            //int ScaleFactor = Convert.ToInt32(Factor);

            if (Factor == 0.5)
            {
                for (int i = 0; i < IngredientQuantities.Length; i++)
                {
                    NewIngredientQuantites[i] = IngredientQuantities[i] / 2;
                }
                Console.WriteLine("Your recipe has been scaled by " + Factor + " successfully!");
            }
            else if (Factor == 2)
            {
                for (int i = 0; i < IngredientQuantities.Length; i++)
                {
                    NewIngredientQuantites[i] = IngredientQuantities[i] * 2;
                }
                Console.WriteLine("Your recipe has been scaled by " + Factor + " successfully!");
            }
            else if (Factor == 3)
            {
                for (int i = 0; i < IngredientQuantities.Length; i++)
                {
                    NewIngredientQuantites[i] = IngredientQuantities[i] * 3;
                }
                Console.WriteLine("Your recipe has been scaled by " + Factor + " successfully!");
            }
            else {
                Console.WriteLine("Invalid!");
            }
            return 0;
        }
        public string ValueReset(int[] IngredientQuantities) {
            for (int i = 0; i < IngredientQuantities.Length; i++) {
                IngredientQuantities[i] = default(int);
            }
            Console.WriteLine("Values reset successfully!");
            return "";
        }
        
    }
    
}
